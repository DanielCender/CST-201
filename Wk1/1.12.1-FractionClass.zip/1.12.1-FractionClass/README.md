# Fraction Class - Book Exercise 1.12.1

This program creates a Fraction from user input and performs operations against it, before reducing it and printing to the console.
## Installation

Clone the Repo and open this project directory, `1.12.1-FractionClass`, in CLion.
## Usage

Run with CLion Compiler or Debugger and watch it go!

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)