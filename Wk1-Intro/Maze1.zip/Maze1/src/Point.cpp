//
// Created by Daniel Cender on 2019-04-26.
//

#include "Point.h"

// implement constructor

// Implement class member functions