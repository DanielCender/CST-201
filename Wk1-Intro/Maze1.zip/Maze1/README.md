# Maze1

This program creates a maze from file input and logs the structure to a file.
## Installation

Clone the Repo and open this project directory, `Maze1`, in CLion, from JetBrains.
## Usage

This was coded in the CLion IDE from JetBrains, available free for academic use at: [link](https://www.jetbrains.com/clion/download/#section=mac).

Run with CLion Compiler or Debugger and watch it go!

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)