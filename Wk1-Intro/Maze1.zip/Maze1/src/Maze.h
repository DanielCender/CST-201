//
// Created by Daniel Cender on 2019-04-26.
//
#include "Point.h"
#ifndef MAZE1_MAZE_H
#define MAZE1_MAZE_H


class Maze {

};


#endif //MAZE1_MAZE_H
