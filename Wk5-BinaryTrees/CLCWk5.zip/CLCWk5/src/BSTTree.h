//
// Created by Daniel Cender on 2019-05-24.
//
#include <iostream>
#include "BSTNode.h"
using namespace std;

#ifndef CLCWK5_SRC_BSTTREE_H_
#define CLCWK5_SRC_BSTTREE_H_

class BSTTree {
 public:
  BSTNode *root;
  BSTTree();
};

#endif //CLCWK5_SRC_BSTTREE_H_
