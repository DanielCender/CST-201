//
// Created by Daniel Cender on 2019-05-24.
//

#include "BSTTree.h"
#include <iostream>
using namespace std;


BSTTree::BSTTree() {}

